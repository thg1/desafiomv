package br.com.thyago.desafiomv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DesafiomvApplication {

	public static void main(String[] args) {
		SpringApplication.run(DesafiomvApplication.class, args);
	}

}
