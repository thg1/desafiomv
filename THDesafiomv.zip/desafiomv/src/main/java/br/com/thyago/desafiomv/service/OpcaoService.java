package br.com.thyago.desafiomv.service;

import java.util.List;

import org.springframework.stereotype.Service;

import br.com.thyago.desafiomv.interfaces.OpcaoImpl;
import br.com.thyago.desafiomv.model.Opcao;
import br.com.thyago.desafiomv.repository.OpcaoRepository;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class OpcaoService implements OpcaoImpl {
	
	private final OpcaoRepository opcaoRepository = new OpcaoRepository();
	
	public Opcao findById(Integer id) {
	    return opcaoRepository.findById(id);
	}

	public List<Opcao> findAll(){
	   return opcaoRepository.findAll();
	}
	
	public void delete(Integer id) {
		opcaoRepository.delete(id);
	}
	
	public void create(Opcao opcao) {
		opcaoRepository.inserir(opcao);
	}

	public void update(Opcao opcao) {
		opcaoRepository.update(opcao);
	}
	

}
