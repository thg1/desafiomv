package br.com.thyago.desafiomv.interfaces;

import java.util.List;

import br.com.thyago.desafiomv.model.CafeDaManha;

public interface CafeDaManhaImpl {
	
	void create(CafeDaManha cafeDaManha) throws Exception;
	
	CafeDaManha findById(Integer id);
	
	List<CafeDaManha> findAll();
	
	void delete(Integer id);

	void update(CafeDaManha cafeDaManha);
}
